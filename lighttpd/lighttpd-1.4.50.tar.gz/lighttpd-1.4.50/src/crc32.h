#ifndef __crc32cr_table_h__
#define __crc32cr_table_h__
#include "first.h"

uint32_t generate_crc32c(const char *string, size_t length);

#endif
